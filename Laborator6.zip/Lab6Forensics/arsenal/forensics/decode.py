import re
import base64
import hashlib
import argparse
import json
from urllib.parse import unquote

s = "Salut"
b = s.encode()
print("A1:")
print(b, b[0])
print(b.hex())
print(bytes.fromhex(b.hex()))


def ghici_strat(s):
    if re.search(r'%[0-9A-Fa-f]{2}', s):
        return "url"
    if re.fullmatch(r'[0-9a-fA-F]+', s) and len(s) % 2 == 0:
        return "hex"
    if re.fullmatch(r'[A-Za-z0-9+/=]+', s):
        return "base64"
    return "necunoscut"


print("\nA2:")
print(ghici_strat("%2Fetc"))
print(ghici_strat("48656c6c6f"))
print(ghici_strat("U2FsdXQ="))


def desfa(s):
    strat = ghici_strat(s)
    if strat == "base64":
        try:
            return strat, base64.b64decode(s)
        except Exception:
            return strat, s.encode()
    elif strat == "hex":
        try:
            return strat, bytes.fromhex(s)
        except Exception:
            return strat, s.encode()
    elif strat == "url":
        return strat, unquote(s).encode()
    return strat, s.encode()


print("\nA3:")
print(desfa("U2FsdXQ="))
print(desfa("48656c6c6f"))
print(desfa("%2Fetc%2Fpasswd"))


def citibil(b):
    if not all(32 <= c < 127 for c in b):
        return False
    litere = sum(1 for c in b if (65 <= c <= 90 or 97 <= c <= 122 or c == 32))
    return litere / len(b) > 0.85


def desfac_straturi(val):
    pasi = []
    for _ in range(8):
        strat, b = desfa(val)
        pasi.append((strat, val[:50]))
        try:
            decoded = b.decode("utf-8")
        except Exception:
            break
        next_strat = ghici_strat(decoded)
        if next_strat == "necunoscut":
            return decoded, pasi
        val = decoded
    return val, pasi


print("\nA4:")
val = open("probe/mesaj.txt").read().strip()
print("Input:", val[:60], "...")
rezultat, pasi = desfac_straturi(val)
print("Pasi parcursi:")
for strat, fragment in pasi:
    print(f"  [{strat}] {fragment}")
print("Rezultat final:", rezultat)


print("\nA5:")
date = open("probe/xor.bin", "rb").read()
for k in range(256):
    clar = bytes(b ^ k for b in date)
    if citibil(clar):
        print("cheie:", k, clar.decode())


print("\nA6:")
linii = open("probe/hashuri.txt").readlines()
for tinta in linii:
    tinta = tinta.strip()
    if not tinta:
        continue
    lungime = len(tinta)
    if lungime == 32:
        algoritm = "md5"
    elif lungime == 40:
        algoritm = "sha1"
    elif lungime == 64:
        algoritm = "sha256"
    else:
        continue
    gasit = False
    for cuv in open("probe/wordlist.txt", encoding="latin1"):
        cuv = cuv.strip()
        if getattr(hashlib, algoritm)(cuv.encode()).hexdigest() == tinta:
            print(f"[{algoritm}] {tinta[:20]}... -> gasit: {cuv}")
            gasit = True
            break
    if not gasit:
        print(f"[{algoritm}] {tinta[:20]}... -> negasit in wordlist")


def ruleaza_decoder(intrare, este_fisier=False):
    if este_fisier:
        with open(intrare, "rb") as f:
            s = f.read().decode(errors="replace").strip()
    else:
        s = intrare
    rezultat, pasi = desfac_straturi(s)
    fisa = {
        "intrare": s[:100],
        "pasi": [{"strat": p[0], "fragment": p[1]} for p in pasi],
        "rezultat": rezultat
    }
    with open("arsenal/forensics/fisa.json", "w", encoding="utf-8") as f:
        json.dump(fisa, f, indent=2, ensure_ascii=False)
    print(f"\nA7:")
    print(f"Pasi: {[p[0] for p in pasi]}")
    print(f"Rezultat: {rezultat}")
    print(f"Fisa salvata in arsenal/forensics/fisa.json")
    return fisa


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("intrare")
    p.add_argument("--fisier", action="store_true")
    a = p.parse_args()
    ruleaza_decoder(a.intrare, a.fisier)
else:
    ruleaza_decoder(open("probe/mesaj.txt").read().strip(), False)
