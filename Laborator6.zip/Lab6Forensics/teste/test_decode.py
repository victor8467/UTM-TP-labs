import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from arsenal.forensics.decode import desfa, ghici_strat, citibil, desfac_straturi


def test_base64():
    strat, b = desfa("U2FsdXQ=")
    assert strat == "base64"
    assert b == b"Salut"
    print("test_base64: TRECUT")


def test_hex():
    strat, b = desfa("48656c6c6f")
    assert strat == "hex"
    assert b == b"Hello"
    print("test_hex: TRECUT")


def test_url():
    strat, b = desfa("%2Fetc%2Fpasswd")
    assert strat == "url"
    assert b == b"/etc/passwd"
    print("test_url: TRECUT")


def test_ghici_strat_url():
    assert ghici_strat("%2Fetc") == "url"
    print("test_ghici_strat_url: TRECUT")


def test_ghici_strat_hex():
    assert ghici_strat("48656c6c6f") == "hex"
    print("test_ghici_strat_hex: TRECUT")


def test_ghici_strat_base64():
    assert ghici_strat("U2FsdXQ=") == "base64"
    print("test_ghici_strat_base64: TRECUT")


def test_citibil():
    assert citibil(b"Hello world") == True
    assert citibil(b"\x00\x01\x02") == False
    print("test_citibil: TRECUT")


def test_straturi_multiple():
    import base64
    layer1 = base64.b64encode(b"Hello world").decode()
    layer2 = layer1.encode().hex()
    rezultat, pasi = desfac_straturi(layer2)
    assert rezultat == "Hello world"
    print("test_straturi_multiple: TRECUT")


if __name__ == "__main__":
    test_base64()
    test_hex()
    test_url()
    test_ghici_strat_url()
    test_ghici_strat_hex()
    test_ghici_strat_base64()
    test_citibil()
    test_straturi_multiple()
    print("\nTOATE testele au trecut!")
