import re
import struct
import zipfile
from PIL import Image
from PIL.ExifTags import TAGS


def tip_real(cale):
    cap = open(cale, "rb").read(8)
    if cap[:4] == b'%PDF':
        return "pdf"
    if cap[:4] == b'\x89PNG':
        return "png"
    if cap[:2] == b'\xff\xd8':
        return "jpeg"
    if cap[:4] == b'PK\x03\x04':
        return "zip/docx"
    return cap.hex()


print("B1:")
print("probe/foto.jpg tip real:", tip_real("probe/foto.jpg"))
print("probe/ascuns.png tip real:", tip_real("probe/ascuns.png"))


print("\nB2:")
date_png = open("probe/ascuns.png", "rb").read()
siruri = re.findall(rb'[ -~]{4,}', date_png)
print(f"Siruri citibile gasite in ascuns.png ({len(siruri)} total):")
for m in siruri:
    print(" ", m.decode())


def rat_la_float(rational):
    if isinstance(rational, tuple):
        numarator, numitor = rational
        return numarator / numitor if numitor != 0 else 0
    return float(rational)


print("\nB3:")
try:
    exif_brut = Image.open("probe/foto.jpg")._getexif() or {}
    print("Tag-uri EXIF gasite:")
    for id_tag, val in exif_brut.items():
        print(f"  {TAGS.get(id_tag, id_tag)} = {val}")
    if 34853 in exif_brut:
        gps = exif_brut[34853]
        print("\nDate GPS brute:", gps)
        lat = rat_la_float(gps[2][0]) + rat_la_float(gps[2][1])/60 + rat_la_float(gps[2][2])/3600
        lon = rat_la_float(gps[4][0]) + rat_la_float(gps[4][1])/60 + rat_la_float(gps[4][2])/3600
        if gps.get(1) == 'S':
            lat = -lat
        if gps.get(3) == 'W':
            lon = -lon
        print(f"Latitudine: {lat:.4f} {gps.get(1, 'N')}")
        print(f"Longitudine: {lon:.4f} {gps.get(3, 'E')}")
except Exception as e:
    print("Eroare citire EXIF:", e)


print("\nB4:")
date_ascuns = open("probe/ascuns.png", "rb").read()
i = date_ascuns.find(b"PK\x03\x04")
if i != -1:
    open("gasit.zip", "wb").write(date_ascuns[i:])
    print(f"Arhiva extrasa de la octetul {i}")
    with zipfile.ZipFile("gasit.zip", "r") as zf:
        print("Fisiere in arhiva:")
        for nume in zf.namelist():
            continut = zf.read(nume).decode(errors="replace")
            print(f"  {nume}: {continut}")


def ascunde_lsb(cale_img, mesaj_bytes, cale_output):
    img = Image.open(cale_img).convert("RGB")
    px = list(img.getdata())
    date_complete = struct.pack('>I', len(mesaj_bytes)) + mesaj_bytes
    biti = "".join(f"{x:08b}" for x in date_complete)
    px_nou = list(px)
    idx_bit = 0
    for i in range(len(px)):
        if idx_bit >= len(biti):
            break
        r, g, b_val = px[i]
        canale = [r, g, b_val]
        for j in range(3):
            if idx_bit < len(biti):
                canale[j] = (canale[j] & ~1) | int(biti[idx_bit])
                idx_bit += 1
        px_nou[i] = tuple(canale)
    img_noua = Image.new("RGB", img.size)
    img_noua.putdata(px_nou)
    img_noua.save(cale_output)
    print(f"Mesaj ascuns in {cale_output} ({len(mesaj_bytes)} octeti, {len(biti)} biti)")


print("\nB5:")
mesaj = b"FLAG{ascuns_in_pixeli}"
ascunde_lsb("probe/foto.jpg", mesaj, "stego.png")


def dezvalui_lsb(cale_stego):
    px = list(Image.open(cale_stego).convert("RGB").getdata())
    biti = ""
    for (r, g, b_val) in px:
        biti += str(r & 1)
        biti += str(g & 1)
        biti += str(b_val & 1)
    lungime = int(biti[:32], 2)
    octeti = []
    for i in range(32, 32 + lungime * 8, 8):
        if i + 8 <= len(biti):
            octeti.append(int(biti[i:i+8], 2))
    return bytes(octeti)


print("\nB6:")
mesaj_recuperat = dezvalui_lsb("stego.png")
print(f"Mesaj dezvaluit: {mesaj_recuperat.decode()}")
print(f"Verificare: {'OK' if mesaj_recuperat == mesaj else 'EROARE'}")
