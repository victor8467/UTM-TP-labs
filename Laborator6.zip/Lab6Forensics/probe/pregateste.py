
# Student: Popa Marius
import base64, os, hashlib, io, zipfile, zlib, struct
from urllib.parse import quote
from PIL import Image, ImageDraw
import piexif

os.makedirs("probe", exist_ok=True)

# 1. mesaj.txt — sir in mai multe straturi de codare
plaintext = "Mesajul secret al laboratorului 6"
layer1 = base64.b64encode(plaintext.encode()).decode()
layer2 = layer1.encode().hex()
layer3 = quote(layer2)
with open("probe/mesaj.txt", "w") as f:
    f.write(layer3)
print("probe/mesaj.txt creat")

# 2. xor.bin — text criptat cu XOR cheie=42
mesaj_xor = "Cheia XOR este patruzeci si doi"
with open("probe/xor.bin", "wb") as f:
    f.write(bytes(b ^ 42 for b in mesaj_xor.encode()))
print("probe/xor.bin creat (cheie=42)")

# 3. hashuri.txt
parole = ["password", "123456", "letmein"]
with open("probe/hashuri.txt", "w") as f:
    for p in parole:
        f.write(hashlib.md5(p.encode()).hexdigest() + "\n")
        f.write(hashlib.sha1(p.encode()).hexdigest() + "\n")
        f.write(hashlib.sha256(p.encode()).hexdigest() + "\n")
print("probe/hashuri.txt creat")

# 4. wordlist.txt
wordlist = ["admin","password","123456","letmein","qwerty","abc123",
            "monkey","dragon","master","sunshine","princess"]
with open("probe/wordlist.txt", "w") as f:
    f.write("\n".join(wordlist))
print("probe/wordlist.txt creat")

# 5. foto.jpg cu EXIF si GPS (Chisinau: 47.0245N, 28.8322E)
img = Image.new("RGB", (100, 100), color=(255, 100, 50))
draw = ImageDraw.Draw(img)
draw.rectangle([10,10,90,90], outline=(0,0,0), width=3)
draw.ellipse([30,30,70,70], fill=(0,150,255))

def dd_to_dms(dd):
    d = int(dd)
    m = int((dd - d) * 60)
    s = round(((dd - d) * 60 - m) * 60 * 100)
    return ((d, 1), (m, 1), (s, 100))

gps_ifd = {
    piexif.GPSIFD.GPSLatitudeRef: b'N',
    piexif.GPSIFD.GPSLatitude: dd_to_dms(47.0245),
    piexif.GPSIFD.GPSLongitudeRef: b'E',
    piexif.GPSIFD.GPSLongitude: dd_to_dms(28.8322),
    piexif.GPSIFD.GPSAltitudeRef: 0,
    piexif.GPSIFD.GPSAltitude: (100, 1),
}
exif_dict = {
    "0th": {
        piexif.ImageIFD.Make: b"Canon",
        piexif.ImageIFD.Model: b"EOS 5D Mark IV",
        piexif.ImageIFD.Software: b"Lab6-Popa-Marius",
    },
    "GPS": gps_ifd
}
img.save("probe/foto.jpg", exif=piexif.dump(exif_dict))
print("probe/foto.jpg creat (cu EXIF si GPS)")

# 6. ascuns.png — png cu zip lipit la coada
def make_png():
    def chunk(name, data):
        c = name + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', 4, 4, 8, 2, 0, 0, 0))
    raw = b''.join(b'\x00' + b'\xff\x00\x00' * 4 for _ in range(4))
    png += chunk(b'IDAT', zlib.compress(raw))
    png += chunk(b'IEND', b'')
    return png

zip_buf = io.BytesIO()
with zipfile.ZipFile(zip_buf, 'w') as zf:
    zf.writestr("secret.txt", "Mesajul ascuns in arhiva: LABORATOR_6_FORENSICS")
with open("probe/ascuns.png", "wb") as f:
    f.write(make_png())
    f.write(zip_buf.getvalue())
print("probe/ascuns.png creat (PNG + ZIP)")
print("\nTOATE fisierele de laborator au fost create in probe/")
