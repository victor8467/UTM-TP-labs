"""Teste pentru decoder. Ruleaza din radacina depozitului:

    python teste/test_decode.py        # fara pytest
    pytest teste/                      # cu pytest (daca il ai instalat)
"""
import base64
import hashlib
import sys
from pathlib import Path
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from arsenal.forensics.decode import (  # noqa: E402
    arata_a_text, citibil, desfa, desfac_straturi, ghici_strat,
    sparge_hash, sparge_xor,
)


def test_base64():
    strat, b = desfa("U2FsdXQ=")
    assert strat == "base64"
    assert b == b"Salut"


def test_hex():
    strat, b = desfa("48656c6c6f")
    assert strat == "hex"
    assert b == b"Hello"


def test_url():
    strat, b = desfa("%2Fetc%2Fpasswd")
    assert strat == "url"
    assert b == b"/etc/passwd"


def test_ghici_strat():
    assert ghici_strat("%2Fetc") == "url"
    assert ghici_strat("48656c6c6f") == "hex"
    assert ghici_strat("U2FsdXQ=") == "base64"
    assert ghici_strat("salut lume!") == "necunoscut"


def test_citibil():
    assert citibil(b"Hello world")
    assert not citibil(b"\x00\x01\x02")
    assert not citibil(b"")


def test_straturi_multiple():
    # base64 -> url -> hex, exact ca in probe/mesaj.txt
    clar = "Salut din laborator"
    s = base64.b64encode(clar.encode()).decode()
    s = quote(s, safe="")
    s = s.encode().hex()
    rezultat, pasi = desfac_straturi(s)
    assert rezultat == clar
    assert [p[0] for p in pasi] == ["hex", "url", "base64"] or \
           [p[0] for p in pasi] == ["hex", "base64"]  # fara % daca nu are padding


def test_text_simplu_ramane_neschimbat():
    # "Salut" are forma de base64, dar nu se decodeaza corect -> ramane text
    rezultat, pasi = desfac_straturi("Salut")
    assert rezultat == "Salut"
    assert pasi == []


def test_xor():
    clar = b"un mesaj de test"
    criptat = bytes(b ^ 77 for b in clar)
    gasite = sparge_xor(criptat)
    assert (77, clar.decode()) in gasite
    assert arata_a_text(clar)


def test_hash():
    cuvinte = ["admin", "dragon", "qwerty"]
    for alg in ("md5", "sha1", "sha256"):
        h = getattr(hashlib, alg)(b"dragon").hexdigest()
        assert sparge_hash(h, cuvinte) == (alg, "dragon")
    assert sparge_hash(hashlib.md5(b"altceva").hexdigest(), cuvinte) == ("md5", None)
    assert sparge_hash("abc", cuvinte) == (None, None)


if __name__ == "__main__":
    teste = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_")]
    for nume, functie in teste:
        functie()
        print(f"{nume}: TRECUT")
    print(f"\nTOATE cele {len(teste)} teste au trecut!")
