"""Lucrarea A - Decoder universal (Lab 6, forensics si steganografie).

Student: Buzdugan Victor

Foloseste:
    python arsenal/forensics/decode.py                         # ruleaza demo-ul A1-A7
    python arsenal/forensics/decode.py "<sir>"                 # desface un sir
    python arsenal/forensics/decode.py probe/mesaj.txt --fisier  # citeste dintr-un fisier
"""
import argparse
import base64
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote

# Caile sunt calculate fata de acest fisier, ca sa mearga din orice director.
BAZA = Path(__file__).resolve().parents[2]
PROBE = BAZA / "probe"
FISA = Path(__file__).resolve().parent / "fisa.json"


# ---------------------------------------------------------------- A1
def incalzire():
    """Diferenta dintre text (str) si octeti (bytes)."""
    s = "Salut"
    b = s.encode()                 # bytes
    print(b, b[0])                 # b'Salut' 83  -> b[0] e un numar, nu o litera
    print(b.hex())                 # 53616c7574
    print(bytes.fromhex(b.hex()))  # b'Salut'


# ---------------------------------------------------------------- A2
def ghici_strat(s):
    """Clasifica un sir dupa forma lui. Ordinea conteaza: url, hex, base64."""
    if re.search(r"%[0-9A-Fa-f]{2}", s):
        return "url"
    if re.fullmatch(r"[0-9a-fA-F]+", s) and len(s) % 2 == 0:
        return "hex"
    if re.fullmatch(r"[A-Za-z0-9+/=]+", s):
        return "base64"
    return "necunoscut"


# ---------------------------------------------------------------- A3
def desfa(s):
    """Desface stratul recunoscut. Intoarce (strat, octeti).

    Daca decodarea esueaza (de ex. base64 cu padding gresit), sirul nu era
    de fapt codat: intoarcem ("necunoscut", s.encode()).
    """
    strat = ghici_strat(s)
    try:
        if strat == "url":
            return strat, unquote(s).encode()
        if strat == "hex":
            return strat, bytes.fromhex(s)
        if strat == "base64":
            return strat, base64.b64decode(s, validate=True)
    except ValueError:  # binascii.Error este o subclasa a lui ValueError
        pass
    return "necunoscut", s.encode()


# ---------------------------------------------------------------- A4
def citibil(b):
    """True daca toti octetii sunt caractere ASCII imprimabile (32..126)."""
    return len(b) > 0 and all(32 <= c < 127 for c in b)


def desfac_straturi(val, max_pasi=8):
    """Desface straturile in bucla. Intoarce (rezultat_final, pasi).

    Ne oprim cand sirul nu mai pare codat, cand decodarea nu mai da text
    citibil (era text simplu care semana cu o codare) sau dupa max_pasi.
    """
    pasi = []
    for _ in range(max_pasi):
        strat, b = desfa(val)
        if strat == "necunoscut" or not citibil(b):
            break
        pasi.append((strat, val[:50]))
        val = b.decode()
    return val, pasi


# ---------------------------------------------------------------- A5
def arata_a_text(b):
    """Mai strict ca citibil(): cel putin 95% litere si spatii."""
    if not citibil(b):
        return False
    litere = sum(1 for c in b if 65 <= c <= 90 or 97 <= c <= 122 or c == 32)
    return litere / len(b) >= 0.95


def sparge_xor(date):
    """Incearca toate cele 256 de chei de un octet. Intoarce [(cheie, text)]."""
    gasite = []
    for k in range(256):
        clar = bytes(b ^ k for b in date)
        if arata_a_text(clar):
            gasite.append((k, clar.decode()))
    return gasite


# ---------------------------------------------------------------- A6
ALGORITMI = {32: "md5", 40: "sha1", 64: "sha256"}


def sparge_hash(tinta, cuvinte):
    """Identifica algoritmul dupa lungime si cauta parola in wordlist.

    Intoarce (algoritm, parola) sau (algoritm, None) daca nu e in wordlist.
    Intoarce (None, None) daca lungimea nu corespunde niciunui algoritm.
    """
    algoritm = ALGORITMI.get(len(tinta))
    if algoritm is None:
        return None, None
    h = getattr(hashlib, algoritm)
    for cuv in cuvinte:
        if h(cuv.encode()).hexdigest() == tinta:
            return algoritm, cuv
    return algoritm, None


# ---------------------------------------------------------------- A7
def ruleaza_decoder(intrare, este_fisier=False):
    """Desface intrarea si salveaza fisa in arsenal/forensics/fisa.json."""
    if este_fisier:
        s = Path(intrare).read_bytes().decode(errors="replace").strip()
    else:
        s = intrare
    rezultat, pasi = desfac_straturi(s)
    fisa = {
        "intrare": s[:100],
        "straturi": [p[0] for p in pasi],
        "pasi": [{"strat": p[0], "fragment": p[1]} for p in pasi],
        "rezultat": rezultat,
    }
    FISA.write_text(json.dumps(fisa, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Straturi: {' -> '.join(fisa['straturi']) or '(niciunul)'}")
    print(f"Rezultat: {rezultat}")
    print(f"Fisa salvata in {FISA.relative_to(BAZA)}")
    return fisa


# ---------------------------------------------------------------- demo
def demo():
    print("A1:")
    incalzire()

    print("\nA2:")
    for ex in ("%2Fetc", "48656c6c6f", "U2FsdXQ=", "salut lume"):
        print(f"  ghici_strat({ex!r}) = {ghici_strat(ex)}")

    print("\nA3:")
    for ex in ("U2FsdXQ=", "48656c6c6f", "%2Fetc%2Fpasswd"):
        print(f"  desfa({ex!r}) = {desfa(ex)}")

    print("\nA4:")
    val = (PROBE / "mesaj.txt").read_text().strip()
    print("Intrare:", val[:60], "...")
    rezultat, pasi = desfac_straturi(val)
    for i, (strat, fragment) in enumerate(pasi, 1):
        print(f"  pas {i} [{strat}] {fragment}")
    print("Rezultat final:", rezultat)

    print("\nA5:")
    date = (PROBE / "xor.bin").read_bytes()
    for cheie, text in sparge_xor(date):
        print(f"  cheie: {cheie} -> {text}")

    print("\nA6:")
    cuvinte = (PROBE / "wordlist.txt").read_text(encoding="latin1").split()
    for tinta in (PROBE / "hashuri.txt").read_text().split():
        algoritm, parola = sparge_hash(tinta, cuvinte)
        if algoritm is None:
            print(f"  lungime necunoscuta ({len(tinta)}): {tinta[:20]}...")
        elif parola is None:
            print(f"  [{algoritm}] {tinta[:20]}... -> negasit in wordlist")
        else:
            print(f"  [{algoritm}] {tinta[:20]}... -> gasit: {parola}")

    print("\nA7:")
    ruleaza_decoder(str(PROBE / "mesaj.txt"), este_fisier=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Decoder universal: base64 / hex / url")
    p.add_argument("intrare", nargs="?", help="sir de decodat, sau cale (cu --fisier)")
    p.add_argument("--fisier", action="store_true", help="intrarea este o cale de fisier")
    a = p.parse_args()
    if a.intrare is None:
        demo()
    else:
        ruleaza_decoder(a.intrare, a.fisier)
