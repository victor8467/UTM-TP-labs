"""Lucrarea B (partea 1) - Forensics pe fisiere: B1-B4.

Student: Buzdugan Victor

Ruleaza din orice director:  python arsenal/forensics/forensics.py
"""
import re
import zipfile
from pathlib import Path

from PIL import Image
from PIL.ExifTags import TAGS

BAZA = Path(__file__).resolve().parents[2]
PROBE = BAZA / "probe"

# Semnaturile (magic bytes) pe care le recunoastem
SEMNATURI = [
    (b"%PDF", "pdf"),
    (b"\x89PNG", "png"),
    (b"\xff\xd8", "jpeg"),
    (b"PK\x03\x04", "zip/docx"),
]


# ---------------------------------------------------------------- B1
def tip_real(cale):
    """Tipul real al fisierului, dupa primii octeti, nu dupa extensie."""
    with open(cale, "rb") as f:   # "rb" - fisier binar, altfel octetii se pot altera
        cap = f.read(8)
    for semnatura, nume in SEMNATURI:
        if cap.startswith(semnatura):
            return nume
    return cap.hex()


# ---------------------------------------------------------------- B2
def strings(cale, minim=4):
    """Secventele de caractere imprimabile (ca utilitarul `strings`)."""
    date = Path(cale).read_bytes()
    return [m.decode() for m in re.findall(rb"[ -~]{%d,}" % minim, date)]


# ---------------------------------------------------------------- B3
def rat_la_float(valoare):
    """Un numar EXIF (IFDRational sau tuplu (num, numitor)) -> float."""
    if isinstance(valoare, tuple):
        num, numitor = valoare
        return num / numitor if numitor else 0.0
    return float(valoare)


def dms_la_zecimal(dms, emisfera):
    grade, minute, secunde = (rat_la_float(x) for x in dms)
    dd = grade + minute / 60 + secunde / 3600
    return -dd if emisfera in ("S", "W") else dd


def citeste_exif(cale):
    """Intoarce (dict_exif_cu_nume, dict_gps) din imagine."""
    exif = Image.open(cale).getexif()
    # 0x8825 e doar un pointer catre blocul GPS, il citim separat mai jos
    general = {TAGS.get(tag, tag): val for tag, val in exif.items() if tag != 0x8825}
    gps = dict(exif.get_ifd(0x8825))   # 0x8825 = 34853 = blocul GPS
    return general, gps


# ---------------------------------------------------------------- B4
def carve_zip(cale_png, cale_iesire):
    """Gaseste semnatura ZIP in fisier si salveaza arhiva separat.

    Intoarce pozitia octetului unde incepe arhiva, sau -1 daca nu exista.
    """
    date = Path(cale_png).read_bytes()
    i = date.find(b"PK\x03\x04")
    if i != -1:
        Path(cale_iesire).write_bytes(date[i:])
    return i


def main():
    foto = PROBE / "foto.jpg"
    ascuns = PROBE / "ascuns.png"

    print("B1:")
    for f in sorted(PROBE.iterdir()):
        if f.suffix in (".jpg", ".png", ".bin"):
            print(f"  {f.relative_to(BAZA)}  (extensie {f.suffix})  tip real: {tip_real(f)}")

    print("\nB2:")
    siruri = strings(ascuns)
    print(f"Siruri citibile in {ascuns.name} ({len(siruri)} total):")
    for s in siruri:
        print(" ", s)

    print("\nB3:")
    general, gps = citeste_exif(foto)
    print("Tag-uri EXIF:")
    for nume, val in general.items():
        print(f"  {nume} = {val}")
    if gps:
        print("\nDate GPS brute:", {k: (tuple(float(x) for x in v) if isinstance(v, tuple) else v)
                                    for k, v in gps.items()})
        lat = dms_la_zecimal(gps[2], gps[1])
        lon = dms_la_zecimal(gps[4], gps[3])
        print(f"Latitudine:  {lat:.4f} {gps[1]}")
        print(f"Longitudine: {lon:.4f} {gps[3]}")
        if 6 in gps:
            print(f"Altitudine:  {rat_la_float(gps[6]):.0f} m")
        print(f"Harta: https://www.google.com/maps?q={lat:.4f},{lon:.4f}")

    print("\nB4:")
    date = ascuns.read_bytes()
    iend = date.find(b"IEND")
    print(f"Sfarsitul PNG-ului (IEND + CRC) la octetul {iend + 8} din {len(date)}")
    iesire = BAZA / "gasit.zip"
    i = carve_zip(ascuns, iesire)
    if i == -1:
        print("Nu am gasit nicio arhiva ZIP.")
    else:
        print(f"Arhiva extrasa de la octetul {i} -> {iesire.name}")
        with zipfile.ZipFile(iesire) as zf:
            print("Fisiere in arhiva:")
            for nume in zf.namelist():
                print(f"  {nume}: {zf.read(nume).decode(errors='replace')}")


if __name__ == "__main__":
    main()
