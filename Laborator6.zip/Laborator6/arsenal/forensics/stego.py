"""Lucrarea B (partea 2) - Steganografie LSB: B5 (ascunde) si B6 (dezvaluie).

Student: Buzdugan Victor

Mesajul se scrie in cel mai putin semnificativ bit (LSB) al fiecarui canal
(R, G, B) de pixel, urmat de un octet 0 care marcheaza sfarsitul mesajului.

Ruleaza din orice director:  python arsenal/forensics/stego.py
"""
from pathlib import Path

from PIL import Image

BAZA = Path(__file__).resolve().parents[2]
PROBE = BAZA / "probe"


# ---------------------------------------------------------------- B5
def ascunde_lsb(cale_img, mesaj, cale_iesire):
    """Ascunde `mesaj` (bytes) in poza gazda si o salveaza ca PNG (fara pierdere)."""
    img = Image.open(cale_img).convert("RGB")
    canale = bytearray(img.tobytes())          # R,G,B,R,G,B,... pentru fiecare pixel
    biti = "".join(f"{octet:08b}" for octet in mesaj + b"\x00")
    if len(biti) > len(canale):
        raise ValueError(f"mesajul e prea lung: {len(biti)} biti, capacitate {len(canale)}")
    for i, bit in enumerate(biti):
        canale[i] = (canale[i] & ~1) | int(bit)    # sterge LSB, pune bitul mesajului
    Image.frombytes("RGB", img.size, bytes(canale)).save(cale_iesire)
    return len(biti)


# ---------------------------------------------------------------- B6
def dezvaluie_lsb(cale_stego):
    """Citeste LSB-urile, le grupeaza cate 8 si se opreste la primul octet 0."""
    canale = Image.open(cale_stego).convert("RGB").tobytes()
    octeti = bytearray()
    for start in range(0, len(canale) - 7, 8):
        octet = 0
        for c in canale[start:start + 8]:
            octet = (octet << 1) | (c & 1)
        if octet == 0:                         # sfarsit de mesaj
            break
        octeti.append(octet)
    return bytes(octeti)


def main():
    gazda = PROBE / "foto.jpg"
    stego = BAZA / "stego.png"
    mesaj = b"FLAG{victor_a_ascuns_in_pixeli}"

    print("B5:")
    nr_biti = ascunde_lsb(gazda, mesaj, stego)
    print(f"Mesaj ascuns in {stego.name}: {len(mesaj)} octeti (+1 terminator) = {nr_biti} biti")

    # cat de mult difera poza stego de original?
    orig = Image.open(gazda).convert("RGB").tobytes()
    nou = Image.open(stego).convert("RGB").tobytes()
    diferente = sum(1 for a, b in zip(orig, nou) if a != b)
    diff_max = max(abs(a - b) for a, b in zip(orig, nou))
    print(f"Canale modificate: {diferente} din {len(orig)}; diferenta maxima pe un canal: {diff_max}")

    print("\nB6:")
    recuperat = dezvaluie_lsb(stego)
    print("Mesaj dezvaluit:", recuperat.decode())
    print("Verificare:", "OK" if recuperat == mesaj else "EROARE")


if __name__ == "__main__":
    main()
