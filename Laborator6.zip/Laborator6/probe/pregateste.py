# Pregatire Lab 6 - genereaza fisierele de analizat in probe/
# Student: Buzdugan Victor
# Ruleaza din radacina depozitului:  python probe/pregateste.py
# Necesita doar Pillow (pip install pillow).
import base64
import hashlib
import io
import zipfile
from pathlib import Path
from urllib.parse import quote

from PIL import Image, ImageDraw
from PIL.TiffImagePlugin import IFDRational

PROBE = Path(__file__).resolve().parent
PROBE.mkdir(exist_ok=True)

# 1. mesaj.txt - sir codat in 3 straturi: base64 -> url -> hex
plaintext = "Victor a desfacut toate straturile laboratorului 6"
strat1 = base64.b64encode(plaintext.encode()).decode()   # base64
strat2 = quote(strat1, safe="")                          # url (=, +, / devin %XX)
strat3 = strat2.encode().hex()                           # hex
assert "%" in strat2, "stratul URL trebuie sa contina cel putin un %XX"
(PROBE / "mesaj.txt").write_text(strat3)
print("probe/mesaj.txt creat (3 straturi: base64 -> url -> hex)")

# 2. xor.bin - text criptat cu XOR, cheie de un octet = 77
CHEIE_XOR = 77
mesaj_xor = "Cheia este saptezeci si sapte"
(PROBE / "xor.bin").write_bytes(bytes(b ^ CHEIE_XOR for b in mesaj_xor.encode()))
print(f"probe/xor.bin creat (cheie={CHEIE_XOR})")

# 3. hashuri.txt - 3 parole x (md5, sha1, sha256)
parole = ["dragon", "qwerty", "monkey"]
with open(PROBE / "hashuri.txt", "w") as f:
    for p in parole:
        for alg in (hashlib.md5, hashlib.sha1, hashlib.sha256):
            f.write(alg(p.encode()).hexdigest() + "\n")
print("probe/hashuri.txt creat")

# 4. wordlist.txt
wordlist = ["admin", "password", "123456", "letmein", "qwerty", "abc123",
            "monkey", "dragon", "master", "sunshine", "princess"]
(PROBE / "wordlist.txt").write_text("\n".join(wordlist))
print("probe/wordlist.txt creat")

# 5. foto.jpg - cu EXIF si GPS (Chisinau, centru: 47.0105 N, 28.8638 E)
LAT, LON = 47.0105, 28.8638


def dd_la_dms(dd):
    grade = int(dd)
    minute = int((dd - grade) * 60)
    secunde = round(((dd - grade) * 60 - minute) * 60 * 100)  # sutimi de secunda
    return (IFDRational(grade, 1), IFDRational(minute, 1), IFDRational(secunde, 100))


img = Image.new("RGB", (200, 200))
px = img.load()
for y in range(200):
    for x in range(200):                      # fundal cu gradient
        px[x, y] = (40 + x // 2, 90 + y // 3, 200 - x // 3)
d = ImageDraw.Draw(img)
d.rectangle([20, 20, 180, 180], outline=(255, 255, 255), width=4)
d.polygon([(100, 45), (160, 150), (40, 150)], fill=(255, 190, 0))
d.ellipse([85, 95, 115, 125], fill=(20, 20, 20))

exif = Image.Exif()
exif[0x010F] = "Nikon"                        # Make
exif[0x0110] = "D750"                         # Model
exif[0x0131] = "Lab6-Buzdugan-Victor"         # Software
exif[0x0132] = "2026:10:18 10:30:00"          # DateTime
gps = exif.get_ifd(0x8825)
gps[1] = "N"
gps[2] = dd_la_dms(LAT)
gps[3] = "E"
gps[4] = dd_la_dms(LON)
gps[5] = 0                                    # altitudine deasupra nivelului marii
gps[6] = IFDRational(85, 1)                   # 85 m
img.save(PROBE / "foto.jpg", exif=exif, quality=95)
print("probe/foto.jpg creat (cu EXIF si GPS)")

# 6. ascuns.png - un PNG real, cu o arhiva ZIP lipita la coada
poza = Image.new("RGB", (64, 64), (30, 30, 30))
dp = ImageDraw.Draw(poza)
dp.rectangle([8, 8, 56, 56], outline=(0, 200, 120), width=3)
dp.line([(8, 8), (56, 56)], fill=(0, 200, 120), width=3)
png_buf = io.BytesIO()
poza.save(png_buf, format="PNG")

zip_buf = io.BytesIO()
with zipfile.ZipFile(zip_buf, "w") as zf:
    zf.writestr("secret.txt", "Arhiva ascunsa: VICTOR_A_GASIT_FISIERUL_ASCUNS")
(PROBE / "ascuns.png").write_bytes(png_buf.getvalue() + zip_buf.getvalue())
print("probe/ascuns.png creat (PNG + ZIP lipit la coada)")

print("\nTOATE fisierele de laborator au fost create in probe/")
